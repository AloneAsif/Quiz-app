
var questions = [
{
    question:"HTML stands for",
    option1:"Hyper Text markup language",
    option2:"Hyper Link markup language",
    option3:"Hyper Text makeup language",
    correctAns:"Hyper Text markup language"
},
{
    question:"Which HTML tag is used to create an ordered list?",
    option1:"<ol>",
    option2:"<ul>",
    option3:"<li>",
    correctAns:"<ol>"
},{
    question:"What is the correct way to comment out multiple lines in HTML?",
    option1:"<!-- This is a comment -->",
    option2:"/* This is a comment */",
    option3:"// This is a comment",
    correctAns:"/* This is a comment */"
},{
    question:"What is the purpose of CSS?",
    option1:"To define the structure of a web page",
    option2:"To add interactivity to a web page",
    option3:"To style the presentation of a web page",
    correctAns:"To style the presentation of a web page"
},{
    question:"What is the function of the document.getElementById() method in JavaScript?",
    option1:"It returns the HTML content of an element",
    option2:"It returns the value of a form field",
    option3:"It returns a reference to an HTML element by its id",
    correctAns:"It returns a reference to an HTML element by its id"
}
,{
    question:" Which property is used to set the background color of an element in CSS?",
    option1:"background-color",
    option2:" color-background",
    option3:"element-background",
    correctAns:"background-color"
}]


var para = document.getElementById("ques");
var opt1 = document.getElementById("opt1");
var opt2 = document.getElementById("opt2");
var opt3 = document.getElementById("opt3");
var button = document.getElementById("btn");
var timer = document.getElementById("timer")
var index = 0;
var score = 0;
// Change the initial values of min and sec to 2 and 0
var min = 2;
var sec = 0;
var timerInterval;


setInterval(function(){
    timer.innerHTML = `${min}:${sec}`;
    sec--
    if(sec<0){
        min--;
        sec = 59    
    }

    if(min< 0){
    
        min= 1;
        sec = 59;
        nextQuestion();
     
    }
},1000)
function stopTimer() {
    clearInterval(timerInterval);
  }


function nextQuestion(){

    var getOptions = document.getElementsByName("options");

    for(var i = 0;i<getOptions.length;i++)
    {
        if(getOptions[i].checked){
            var selectedValue = getOptions[i].value;
            // console.log(selectedValue)
            var selectedQues = questions[index - 1]["question"];
            var selectedAns = questions[index-1][`option${selectedValue}`]
            var correctAns = questions[index - 1]["correctAns"]
            if(selectedAns == correctAns){
                score++ 
            }
        }
        getOptions[i].checked = false
    }

    button.disabled = true
    if (index > questions.length - 1) { 
        // for percentage
               var percentages;
               percentages = ((score / questions.length)*100).toFixed(2);
               if(percentages > 70){
        Swal.fire(
            'Good job!',
            `Your percentage is ${percentages}`,
            'success'
            )
        }
        else if(percentages < 70 && percentages > 50){
            Swal.fire(
                'Just Fine!',
                `Your percentage is ${percentages}`,
                'Keep it up'
                )
            
        }
        else if(percentages < 50){

           Swal.fire(
                'You failed!',
                `Your percentage is ${percentages}`,
                'Keep it up'
                )

        }
            
            
        // console.log("your percentage is " + ((score / questions.length)*100).toFixed(2))
    }
    else{

        
        para.innerHTML = questions[index].question;
        opt1.innerText = questions[index].option1;
        opt2.innerText = questions[index].option2;
        opt3.innerText = questions[index].option3;
        index++
        // Reset the min and sec values to 2 and 0
        min= 1;
        sec = 59;
        
    }
}

// nextQuestion()


function clicked()
{
    button.disabled = false
}
